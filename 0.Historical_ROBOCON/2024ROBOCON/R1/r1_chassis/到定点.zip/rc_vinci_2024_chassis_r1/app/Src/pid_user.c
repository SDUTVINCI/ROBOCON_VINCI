#include "pid_user.h"
#include "can_receive.h"

extern motor_measure_t motor_can1[8];
extern moto_info_t motor_info[MOTOR_MAX_NUM];
extern ops9_t ops9;
pid_type_def pid_v_chassis_3508[3]
, pid_v_chassis_6020[3]
,pid_p_chassis_6020[3]

,pid_position_chassis_omega
,pid_position_chassis_y
,pid_position_chassis_x;//  0:  x方向   1：y方向



float motor_speed_3508_pid[3] = {20, 0.1, 0}; // 底盘3508参数
float motor_position_3508_pid[3] = {0.2, 0, 1};
//float motor_speed_2006_pid[3] = {8.3, 0.1, 1}; // 底盘2006参数
//float motor_position_2006_pid[3] = {0.27, 0.022, 0.7};
float motor_speed_6020_pid[3] = {40, 3, 0};
float motor_position_6020_pid[3]={0.3,0,0.2};
float motor_position_chassis[3]={10,0,0.02};
float motor_position_chassis_omega[3]={0.5,0,0.02};//{0.5,0,0.02};
#define LimitMax(input, max)                                  \
	{                                             \
		if (input > max)              \
		{                             \
			input = max;  \
		}                             \
		else if (input < -max)        \
		{                             \
			input = -max; \
		}                             \
	}

// 底盘电机PID初始化
void PID_devices_Init(void)
{

	for (uint8_t i = 0; i < 3; i++)
	{
		PID_init(&pid_v_chassis_3508[i], PID_POSITION, motor_speed_3508_pid, 10000, 6000); // 3508  speed   
		PID_init(&pid_v_chassis_6020[i], PID_POSITION, motor_speed_6020_pid, 30000, 30000); // 6020 speed
		PID_init(&pid_p_chassis_6020[i], PID_POSITION, motor_position_6020_pid, 20000, 20000); // 6020 position
		
	}
	PID_init(&pid_position_chassis_x, PID_POSITION, motor_position_chassis, 800, 800);
	PID_init(&pid_position_chassis_y, PID_POSITION, motor_position_chassis, 800, 800);
	PID_init(&pid_position_chassis_omega, PID_POSITION, motor_position_chassis_omega,3, 3);
	
	
	
//	PID_init(&pid_position_chassis_x, PID_POSITION, motor_position_chassis, 330, 330);
//	PID_init(&pid_position_chassis_y, PID_POSITION, motor_position_chassis, 330, 330);
//	PID_init(&pid_position_chassis_omega, PID_POSITION, motor_position_chassis_omega, 3, 3);
}
 fp32 PID_position_chassis_x(fp32 set_position)//position
{
		PID_calc(&pid_position_chassis_x ,ops9.Position.pos_x , set_position);
		return pid_position_chassis_x.out;
}
 fp32 PID_position_chassis_y(fp32 set_position )//position
{
		PID_calc(&pid_position_chassis_y,ops9.Position.pos_y, set_position);
		return pid_position_chassis_y.out;
}


 fp32 PID_position_chassis_omega(fp32 set_omega )//position
{
		PID_calc(&pid_position_chassis_omega,ops9.Euler.yaw, set_omega);
		return pid_position_chassis_omega.out;
}





 fp32 PID_velocity_realize_6020(fp32 set_speed,int i)//can2 6020 speed
{
		PID_calc(&pid_v_chassis_6020[i-1],motor_info[i-1].rotor_speed , set_speed);
		return pid_v_chassis_6020[i-1].out;
}

fp32 PID_velocity_realize_chassis_3508(fp32 set_speed, int i) // can1 3508 speed
{
	PID_calc(&pid_v_chassis_3508[i - 1], motor_can1[i - 1].speed_rpm, set_speed);
	return pid_v_chassis_3508[i - 1].out;
}

fp32 PID_position_6020(fp32 set_pos,int i)
{

		PID_calc_6020_postion(&pid_p_chassis_6020[i-1],motor_info[i-1].rotor_angle , set_pos);
		return pid_p_chassis_6020[i-1].out;

}

 fp32 PID_call_6020(fp32 position,int i)
{
		return PID_velocity_realize_6020(PID_position_6020(position,i),i);
}
