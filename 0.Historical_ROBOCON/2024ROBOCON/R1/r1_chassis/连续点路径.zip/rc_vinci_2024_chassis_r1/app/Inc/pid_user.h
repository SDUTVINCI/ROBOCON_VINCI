#ifndef __PID_USER_H
#define __PID_USER_H
#include "pid.h"
#include "include.h"

void PID_devices_Init(void);
 fp32 PID_velocity_realize_6020(fp32 set_speed,int i);
fp32 PID_velocity_realize_chassis_3508(fp32 set_speed,int i);
fp32 PID_position_6020(fp32 set_pos,int i);
 fp32 PID_call_6020(fp32 position,int i);

 fp32 PID_position_chassis_x(fp32 set_position);
 fp32 PID_position_chassis_y(fp32 set_position );
 fp32 PID_position_chassis_omega(fp32 set_omega );//position

#endif























