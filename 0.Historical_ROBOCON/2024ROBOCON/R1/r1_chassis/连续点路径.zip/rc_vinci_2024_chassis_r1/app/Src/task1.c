#include "include.h"
int16_t points[29][3] = {
    
    {300,300,0},
    {750,280},
    {1000, 250, 0},
    {1250, 250, 0},
    {1500, 250, 0},
    {1750, 250, 0},
    {2000, 250, 0},
    {2250, 250, 0},
    {1125, 2850, 0},
    {1625, 2850, 0},
    {2125, 2850, 0},
    {2625, 2850, 0},
    {3125, 2850, 0},
    {3625, 2850, 0},
    
    {4120,2850,0},
    {4120,1200},
    
{2500, 250, 0},
    {2750, 250, 0},
    {3000, 250, 0},
    {3250, 250, 0},
    {3500, 250, 0},
    {3750, 250, 0},
    {3700, 1700, 60},
    {3200, 1700, 60},
    {2700, 1700, 60},
    {2200, 1700, 60},
    {1700, 1700, 60},
    {1200, 1700, 60},
    {10, 50, 0}};
extern RC_ctrl_t rc_ctrl;
extern ops9_t ops9;
extern pid_type_def pid_v_chassis_3508[3], pid_v_chassis_6020[3], pid_p_chassis_6020[3];

void move_mode2(void);
uint8_t move_points(uint8_t points_number, int16_t points[][3]);
void StartTask02(void const *argument)
{
	// ����һ��ʱ��
	vTaskDelay(CHASSIS_TASK_INIT_TIME);
	for (;;)
	{
		move_points(29, points);
		osDelay(5);
	}
}

// 0��0��0  ʱ   ��������
void move_mode1(void)
{
	chassis_t chassis_r1;
	wheel_t wheel_r1;
	chassis_r1.Vx = -rc_ctrl.rc.ch[0] * 2;
	chassis_r1.Vy = -rc_ctrl.rc.ch[1] * 2;
	chassis_r1.Vomega = rc_ctrl.rc.ch[2] / 60;
	if (chassis_r1.Vy == 0 && chassis_r1.Vx == 0 && chassis_r1.Vomega == 0)
	{
		gm6020_cmd(PID_velocity_realize_6020(0, 1), PID_velocity_realize_6020(0, 2), PID_velocity_realize_6020(0, 3), 0);
		gm3508_cmd(PID_velocity_realize_chassis_3508(0, 1), PID_velocity_realize_chassis_3508(0, 2), PID_velocity_realize_chassis_3508(0, 3), 0);
	}
	else
	{
		wheel_r1 = Formula(chassis_r1);
		gm6020_cmd(PID_call_6020(tansform_6020(wheel_r1.theta[0]), 1), PID_call_6020(tansform_6020(wheel_r1.theta[1]), 2), PID_call_6020(tansform_6020(wheel_r1.theta[2]), 3), 0);
		gm3508_cmd(PID_velocity_realize_chassis_3508(wheel_r1.V[0] * cos(pid_p_chassis_6020[0].error[0] / 1305), 1), PID_velocity_realize_chassis_3508(wheel_r1.V[1] * cos(pid_p_chassis_6020[1].error[0] / 1305), 2), PID_velocity_realize_chassis_3508(wheel_r1.V[2] * cos(pid_p_chassis_6020[2].error[0] / 1305), 3), 0);
	}
}

void move_mode2(void)
{
	chassis_t chassis_r1_world;
	chassis_r1_world.Vx = -rc_ctrl.rc.ch[0] * 5;
	chassis_r1_world.Vy = -rc_ctrl.rc.ch[1] * 5;
	chassis_r1_world.Vomega = rc_ctrl.rc.ch[2] / 60;
	chassis_t chassis_r1_robot;
	wheel_t wheel_r1;
	chassis_r1_robot = Formula_World2Robo(chassis_r1_world, ops9.Euler.yaw / 57.32);

	wheel_r1 = Formula(chassis_r1_robot);
	gm6020_cmd(PID_call_6020(tansform_6020(wheel_r1.theta[0]), 1), PID_call_6020(tansform_6020(wheel_r1.theta[1]), 2), PID_call_6020(tansform_6020(wheel_r1.theta[2]), 3), 0);
	gm3508_cmd(PID_velocity_realize_chassis_3508(wheel_r1.V[0] * cos(pid_p_chassis_6020[0].error[0] / 1305), 1), PID_velocity_realize_chassis_3508(wheel_r1.V[1] * cos(pid_p_chassis_6020[1].error[0] / 1305), 2), PID_velocity_realize_chassis_3508(wheel_r1.V[2] * cos(pid_p_chassis_6020[2].error[0] / 1305), 3), 0);
}
void move_mode3(void)
{
	chassis_t chassis_r1_world;
	chassis_t chassis_r1_robot;
	wheel_t wheel_r1;

	chassis_r1_world.Vx = -rc_ctrl.rc.ch[0];
	chassis_r1_world.Vy = -rc_ctrl.rc.ch[1];
	chassis_r1_world.Vomega = rc_ctrl.rc.ch[2] / 60;

	chassis_r1_robot = Formula_World2Robo(chassis_r1_world, ops9.Euler.yaw / 57.32);

	wheel_r1 = Formula(chassis_r1_robot);
	gm6020_cmd(PID_call_6020(tansform_6020(wheel_r1.theta[0]), 1), PID_call_6020(tansform_6020(wheel_r1.theta[1]), 2), PID_call_6020(tansform_6020(wheel_r1.theta[2]), 3), 0);
	gm3508_cmd(PID_velocity_realize_chassis_3508(wheel_r1.V[0] * cos(pid_p_chassis_6020[0].error[0] / 1305), 1), PID_velocity_realize_chassis_3508(wheel_r1.V[1] * cos(pid_p_chassis_6020[1].error[0] / 1305), 2), PID_velocity_realize_chassis_3508(wheel_r1.V[2] * cos(pid_p_chassis_6020[2].error[0] / 1305), 3), 0);
}
// ��������һ���Ƕ�   δ���ﷵ��0������λ�÷���1
uint8_t move_mode4(int world_x, int world_y, float omega) // ������
{

	if ((omega - ops9.Euler.yaw > 4 || omega - ops9.Euler.yaw < -4) || (world_x - ops9.Position.pos_x > 3 || world_x - ops9.Position.pos_x < -3) || (world_y - ops9.Position.pos_y > 3 || world_y - ops9.Position.pos_y < -3))
	{

		chassis_t chassis_r1_world;		        // ��������ϵ
		chassis_t chassis_r1_robot;		        // ����������ϵ
		wheel_t wheel_r1;		        // ��ϵ
		chassis_r1_world.Vx = -PID_position_chassis_x(world_x); // position
		chassis_r1_world.Vy = -PID_position_chassis_y(world_y); // position
		chassis_r1_world.Vomega = -PID_position_chassis_omega(omega);
		chassis_r1_robot = Formula_World2Robo(chassis_r1_world, ops9.Euler.yaw / 57.32);
		wheel_r1 = Formula(chassis_r1_robot);
		gm6020_cmd(PID_call_6020(tansform_6020(wheel_r1.theta[0]), 1), PID_call_6020(tansform_6020(wheel_r1.theta[1]), 2), PID_call_6020(tansform_6020(wheel_r1.theta[2]), 3), 0);
		gm3508_cmd(PID_velocity_realize_chassis_3508(wheel_r1.V[0] * cos(pid_p_chassis_6020[0].error[0] / 1305), 1), PID_velocity_realize_chassis_3508(wheel_r1.V[1] * cos(pid_p_chassis_6020[1].error[0] / 1305), 2), PID_velocity_realize_chassis_3508(wheel_r1.V[2] * cos(pid_p_chassis_6020[2].error[0] / 1305), 3), 0);
		return 0;
	}

	else
	{
		gm6020_cmd(PID_velocity_realize_6020(0, 1), PID_velocity_realize_6020(0, 2), PID_velocity_realize_6020(0, 3), 0);
		gm3508_cmd(PID_velocity_realize_chassis_3508(0, 1), PID_velocity_realize_chassis_3508(0, 2), PID_velocity_realize_chassis_3508(0, 3), 0);

		return 1;
	}
}
// ׷�����    �������յ㷵��0    δ�������յ㷵������׷�ĵ������
// points_number���������
// points[][3]��ŵ������
uint8_t move_points(uint8_t points_number, int16_t points[][3])
{
	static uint8_t step = 0;
	uint8_t flage = 0;
	if (step == points_number) // �������յ�  ����0
	{
		move_mode4(points[points_number - 1][0], points[points_number - 1][1], points[points_number - 1][2]);
		return 0;
	}
	else // δ�������յ�  ��������׷�ĵ������
	{
		flage = move_mode4(points[step][0], points[step][1], points[step][2]);
		if (flage)
		{
			step += 1;
		}
		if (step == points_number)
		{
			return 0;
		}
		return step + 1;
	}
}
